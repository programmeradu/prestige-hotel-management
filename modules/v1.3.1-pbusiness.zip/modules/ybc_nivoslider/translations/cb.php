<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Diapositiva de imágenes en su página de inicio';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Añade una presentación de imágenes en su página de inicio.';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Valores no válidos';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Diapositiva no válida';
$_MODULE['<{homeslider}prestashop>homeslider_e0ce30bfbf90d2306ecf72f06a83133f'] = 'Estado de diapositivas no válido.';
$_MODULE['<{homeslider}prestashop>homeslider_9f79795e050649dc6b8bd0cdc874cbdc'] = 'Posición de diapositiva no válida.';
$_MODULE['<{homeslider}prestashop>homeslider_5c8bedc4c0c9f42d9b0f14340bbe53da'] = 'ID de diapósitiva inválido';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'El título es demasiado largo.';
$_MODULE['<{homeslider}prestashop>homeslider_dc89634d1d28cd4e055531e62047156b'] = 'El título es demasiado largo.';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'La URL es demasiado larga.';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'La descripción es demasiado larga.';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Formato de URL no es correcto.';
$_MODULE['<{homeslider}prestashop>homeslider_73133ce32267e8c7a854d15258eb17e0'] = 'Nombre de archivo no válido.';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'El título no está definido.';
$_MODULE['<{homeslider}prestashop>homeslider_a9af2809b02444b9470f97dc66ba57a2'] = 'El título no está establecido.';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'La URL no se definido.';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'La imagen no ha sido definida.';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'La configuración no se ha podido actualizar.';
$_MODULE['<{homeslider}prestashop>homeslider_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'Se ha producido un error durante el envío del archivo.';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'La diapositiva no se ha podido agregar.';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'La diapositiva no se ha podido actualizar.';
$_MODULE['<{homeslider}prestashop>homeslider_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{homeslider}prestashop>homeslider_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{homeslider}prestashop>homeslider_ced7338587c502f76917b5a693f848c5'] = 'Información de la Diapositiva';
$_MODULE['<{homeslider}prestashop>homeslider_792744786ed30c5623dd1cf0c16f4ffe'] = 'Seleccione un archivo';
$_MODULE['<{homeslider}prestashop>homeslider_61c1727eb4c54b859e250c2a76bb40c0'] = 'Título de la Diapositiva';
$_MODULE['<{homeslider}prestashop>homeslider_e64df1d7c22b9638f084ce8a4aff3ff3'] = 'URL de destino';
$_MODULE['<{homeslider}prestashop>homeslider_272ba7d164aa836995be6319a698be84'] = 'Título';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descripción';
$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Si';
$_MODULE['<{homeslider}prestashop>homeslider_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{homeslider}prestashop>homeslider_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{homeslider}prestashop>homeslider_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{homeslider}prestashop>homeslider_1738daa45f573390d5745fd33ec03fa1'] = 'Ancho máximo de la imagen';
$_MODULE['<{homeslider}prestashop>homeslider_44877c6aa8e93fa5a91c9361211464fb'] = 'Velocidad';
$_MODULE['<{homeslider}prestashop>homeslider_11cd394e1bd88abe611fd331887f0c74'] = 'La duración de la transición entre dos diapositivas.';
$_MODULE['<{homeslider}prestashop>homeslider_105b296a83f9c105355403f3332af50f'] = 'Pausa';
$_MODULE['<{homeslider}prestashop>homeslider_44f0ca4d7ea17bb667e8d5e31311d959'] = 'El retraso entre dos diapositivas.';
$_MODULE['<{homeslider}prestashop>homeslider_1e6a508c037fc42ef6155eeadbb80331'] = 'Reproducción automática';
$_MODULE['<{homeslider}prestashop>homeslider_5a3489cc067f89b268b6958bffb98ebf'] = 'Dado que varios idiomas se activaron en su tienda, por favor recuerde subir su imagen para cada uno de ellos';
$_MODULE['<{homeslider}prestashop>homeslider_c8a1ed10db4201b3ae06ea0aa912028d'] = 'No puede gestionar los elementos de diapositivas para el contexto de "Todas las tiendas" o un "Grupo de tiendas", seleccione directamente la tienda que quiere editar';
$_MODULE['<{homeslider}prestashop>homeslider_71063fd397d237e563089c22dd8b69e8'] = 'Las modificaciones se aplicacarán sobre todas las tiendas y grupos de tiendas';
$_MODULE['<{homeslider}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Elija un archivo';
$_MODULE['<{homeslider}prestashop>list_c82324ebbcea34f55627a897b37190e3'] = 'Lista de diapositivas';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Editar';
$_MODULE['<{homeslider}prestashop>list_f2a6c498fb90ee345d997f888fce3b18'] = 'Eliminar';


return $_MODULE;
