<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_53eef1dc1c84ebd17d645173b7b7655a'] = 'サーチ：';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_53eef1dc1c84ebd17d645173b7b7655a'] = 'サーチ：';
