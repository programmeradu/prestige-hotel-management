<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */

 include_once dirname(__FILE__) . "/class-paystack-plugin-tracker.php";
class PaystackPaystacksuccessModuleFrontController extends ModuleFrontController
{
    private function verify_txn($code)
    {
        $test_secretkey = Configuration::get('PAYSTACK_TEST_SECRETKEY');
        $live_secretkey = Configuration::get('PAYSTACK_LIVE_SECRETKEY');
        $mode = Configuration::get('PAYSTACK_MODE');

        $key = ($mode == '1') ? $test_secretkey : $live_secretkey;
        $key = trim($key);

        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($code),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    "Authorization: Bearer " . $key,
                    "Cache-Control: no-cache",
                    "Accept: application/json"
                ],
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_SSL_VERIFYPEER => true
            ]);

            $response = curl_exec($ch);
            $err = curl_error($ch);
            curl_close($ch);
            
            if ($err) {
                PrestaShopLogger::addLog('Paystack verification error: '.$err, 3);
                return false;
            }

            return json_decode($response);
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Paystack verification exception: '.$e->getMessage(), 3);
            return false;
        }
    }

    public function initContent()
    {
        parent::initContent();

        $cart = $this->context->cart;
        if (!$cart->id || $cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0) {
            Tools::redirect('index.php?controller=order&step=1');
            return;
        }

        // Get the transaction reference
        $reference = Tools::getValue('reference');
        if (empty($reference)) {
            Tools::redirect('index.php?controller=order&step=3&error=missing_reference');
            return;
        }

        // Verify the transaction
        $verification = $this->verify_txn($reference);
        if (!$verification || !$verification->status || !property_exists($verification, 'data') || $verification->data->status !== 'success') {
            PrestaShopLogger::addLog('Paystack payment failed: Reference='.$reference, 3, null, 'Cart', $cart->id, true);
            Tools::redirect('index.php?controller=order&step=3&error=payment_failed');
            return;
        }

        try {
            // Get payment details
            $amount = $verification->data->amount / 100; // Convert from kobo/cents
            $email = $verification->data->customer->email;
            $currency = new Currency($cart->id_currency);
            $customer = new Customer($cart->id_customer);

            // Prepare extra variables for order
            $extra_vars = array(
                'transaction_id' => $reference,
                'payment_method' => isset($verification->data->channel) ? ucfirst($verification->data->channel) : 'Paystack',
                'status' => 'Paid',
                'currency' => $currency->iso_code
            );

            // Create the order
            $this->module->validateOrder(
                $cart->id,
                Configuration::get('PS_OS_PAYMENT'),
                $amount,
                $this->module->displayName,
                'Paystack Reference: ' . $reference,
                $extra_vars,
                (int)$currency->id,
                false,
                $customer->secure_key
            );

            // Redirect to confirmation page
            if (Module::isInstalled('hotelreservationsystem')) {
                // QloApps specific redirect
                $order_reference = Order::getOrderByCartId($cart->id);
                $order = new Order($order_reference);
                Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$order->id.'&key='.$customer->secure_key);
            } else {
                // Standard PrestaShop redirect
                Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
            }
        } catch (Exception $e) {
            PrestaShopLogger::addLog('Paystack order creation error: '.$e->getMessage(), 3, null, 'Cart', $cart->id, true);
            Tools::redirect('index.php?controller=order&step=3&error=order_creation_failed');
        }
    }
}
